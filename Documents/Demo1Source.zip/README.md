# ProTrackCS360

In order to view the current state of this project, visit:
https://schlegs88.github.io/ProTrackCS360/

The HTML files will be
Home  - login/register
Dashboard
Calendar
Viewing a Project 
Testing Validation

These pages are subject to change
